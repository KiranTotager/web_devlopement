let userscore=0;
let computerscore=0;
const computerChoice=()=>{
    let choices=["rock","paper","scesor"];
    return choices[Math.floor(Math.random()*3)];
}
function showResult(userWin){
    if(userWin){
        document.querySelector(".message").innerHTML="<strong>Hurray...you win🤩!</strong>";
        userscore++;
        document.querySelector(".user").firstElementChild.innerHTML=userscore;
    }else{
        document.querySelector(".message").innerHTML="<strong>better luck next time☹</strong>";
        computerscore++;
        document.querySelector(".computer").firstElementChild.innerHTML=computerscore;
    }
}

const playGame=(userChoice)=>{
    const cmptrChoice=computerChoice();
    console.log("computer choice is",cmptrChoice);
    if(userChoice===cmptrChoice){
        document.querySelector(".message").innerHTML="<strong>Match Tie....!</strong>"
    }else{
        let userWin=true;
        if(userChoice==="rock"){
            userWin=cmptrChoice=="paper"?false:true;
        }
        else if(userChoice==="paper"){
            userWin=cmptrChoice=="scesor"?false:true;
        }
       else{
            userWin=cmptrChoice=="rock"?false:true;
        }
        showResult(userWin);
    }

}
let choices=document.querySelectorAll(".choice1");
choices.forEach((choice)=>{
    choice.addEventListener("click",()=>{
    userChoice = choice.getAttribute("id");
    playGame(userChoice);
});
});